import { useCallback, useMemo, useState } from "react";
import { Alert, Image, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
import ScreenContainer from "../src/components/ScreenContainer";
import ThemedCard from "../src/components/ThemedCard";
import ThemedButton from "../src/components/ThemedButton";
import LuxuryInput from "../src/components/LuxuryInput";
import { api } from "../src/lib/api";
import { formatAmount, theme } from "../src/theme/theme";

const whiteChip = require("../assets/chips/white.png");
const redChip = require("../assets/chips/red.png");
const blueChip = require("../assets/chips/blue.png");
const greenChip = require("../assets/chips/green.png");
const blackChip = require("../assets/chips/black.png");
const caseImage = require("../assets/images/chips-case.png");

type InputMode = "TOTAL_AMOUNT" | "CHIP_BREAKDOWN";
type ChipKey = "white" | "red" | "blue" | "green" | "black";
type ChipCounts = Record<ChipKey, number>;

const chipConfig: Array<{ key: ChipKey; label: string; value: number; image: any }> = [
    { key: "white", label: "White", value: 1, image: whiteChip },
    { key: "red", label: "Red", value: 5, image: redChip },
    { key: "blue", label: "Blue", value: 10, image: blueChip },
    { key: "green", label: "Green", value: 25, image: greenChip },
    { key: "black", label: "Black", value: 50, image: blackChip },
];

export default function CashoutScreen() {
    const router = useRouter();
    const params = useLocalSearchParams<{ fromSession?: string }>();

    const [mode, setMode] = useState<InputMode>("CHIP_BREAKDOWN");
    const [amount, setAmount] = useState("0");
    const [submitting, setSubmitting] = useState(false);
    const [sessionOpen, setSessionOpen] = useState(false);
    const [chips, setChips] = useState<ChipCounts>({
        white: 0,
        red: 0,
        blue: 0,
        green: 0,
        black: 0,
    });

    function updateChip(key: ChipKey, value: string) {
        const numeric = Math.max(0, Number(value.replace(/[^0-9]/g, "") || 0));
        setChips((prev) => ({ ...prev, [key]: numeric }));
    }

    const totalFromChips = useMemo(() => {
        return (
            chips.white * 1 +
            chips.red * 5 +
            chips.blue * 10 +
            chips.green * 25 +
            chips.black * 50
        );
    }, [chips]);

    async function loadData() {
        const response = await api.get("/sessions/active");
        setSessionOpen(!!response.data.activeSession);
    }

    useFocusEffect(
        useCallback(() => {
            loadData().catch(() => { });
        }, [])
    );

    async function submitCashout() {
        try {
            if (!sessionOpen) {
                Alert.alert("No active session", "Cash out is allowed only during an active session.");
                return;
            }

            setSubmitting(true);

            if (mode === "TOTAL_AMOUNT") {
                if (amount === "" || Number(amount) < 0) {
                    Alert.alert("Invalid amount", "Enter a valid amount.");
                    return;
                }

                await api.post("/conversion-requests", {
                    type: "TO_COINS",
                    amount_mode: "TOTAL_AMOUNT",
                    amount_total: Number(amount),
                });
            } else {
                await api.post("/conversion-requests", {
                    type: "TO_COINS",
                    amount_mode: "CHIP_BREAKDOWN",
                    white_count: chips.white,
                    red_count: chips.red,
                    blue_count: chips.blue,
                    green_count: chips.green,
                    black_count: chips.black,
                });
            }

            Alert.alert("Cash out requested", "The admin will review your exit request.");
            router.replace("/(tabs)/session");
        } catch (error: any) {
            Alert.alert("Error", error?.response?.data?.message || "Failed to send cash out");
        } finally {
            setSubmitting(false);
        }
    }

    if (!sessionOpen) {
        return (
            <ScreenContainer>
                <ThemedCard glow="gold">
                    <Text style={styles.noticeTitle}>No active session</Text>
                    <Text style={styles.noticeText}>
                        Cash out is available only while a session is open.
                    </Text>
                    <View style={{ marginTop: 16 }}>
                        <ThemedButton title="Back to Session" onPress={() => router.replace("/(tabs)/session")} />
                    </View>
                </ThemedCard>
            </ScreenContainer>
        );
    }

    return (
        <ScreenContainer>
            <View style={styles.header}>
                <View style={{ flex: 1 }}>
                    <Text style={styles.title}>Cash Out</Text>
                    <Text style={styles.subtitle}>
                        Leave the table and convert your chips back into Double O.
                    </Text>
                </View>
                <Image source={caseImage} style={styles.caseImage} />
            </View>

            {params.fromSession === "1" ? (
                <ThemedCard glow="gold" style={{ marginBottom: 16 }}>
                    <Text style={styles.noticeTitle}>Leaving the table</Text>
                    <Text style={styles.noticeText}>
                        You can submit 0 if you lost everything. Your exit remains pending until the admin approves it.
                    </Text>
                </ThemedCard>
            ) : null}

            <ThemedCard glow="gold">
                <Text style={styles.sectionLabel}>Input Mode</Text>

                <View style={styles.segmentRow}>
                    <Segment active={mode === "CHIP_BREAKDOWN"} label="Chips" onPress={() => setMode("CHIP_BREAKDOWN")} />
                    <Segment active={mode === "TOTAL_AMOUNT"} label="Amount" onPress={() => setMode("TOTAL_AMOUNT")} />
                </View>

                {mode === "TOTAL_AMOUNT" ? (
                    <View style={{ marginTop: 18 }}>
                        <LuxuryInput
                            label="Double O to receive"
                            placeholder="Enter amount"
                            value={amount}
                            onChangeText={setAmount}
                            keyboardType="numeric"
                        />
                    </View>
                ) : (
                    <View style={{ marginTop: 18, gap: 12 }}>
                        {chipConfig.map((chip) => (
                            <View key={chip.key} style={styles.chipRow}>
                                <View style={styles.chipLeft}>
                                    <Image source={chip.image} style={styles.chipImage} />
                                    <View>
                                        <Text style={styles.chipName}>{chip.label}</Text>
                                        <Text style={styles.chipValue}>Value: {chip.value}</Text>
                                    </View>
                                </View>

                                <TextInput
                                    value={chips[chip.key] ? String(chips[chip.key]) : ""}
                                    onChangeText={(value) => updateChip(chip.key, value)}
                                    keyboardType="numeric"
                                    placeholder="0"
                                    placeholderTextColor={theme.colors.muted}
                                    style={styles.chipInput}
                                />
                            </View>
                        ))}

                        <View style={styles.totalBox}>
                            <Text style={styles.totalLabel}>Calculated cash out</Text>
                            <Text style={styles.totalValue}>{formatAmount(totalFromChips)} O²</Text>
                        </View>
                    </View>
                )}

                <View style={styles.actionStack}>
                    <ThemedButton
                        title={submitting ? "Sending..." : "Send Cash Out Request"}
                        onPress={submitCashout}
                        loading={submitting}
                    />
                    <ThemedButton
                        title="Back to Session"
                        variant="dark"
                        onPress={() => router.replace("/(tabs)/session")}
                    />
                </View>
            </ThemedCard>
        </ScreenContainer>
    );
}

function Segment({
    active,
    label,
    onPress,
}: {
    active: boolean;
    label: string;
    onPress: () => void;
}) {
    return (
        <Pressable
            onPress={onPress}
            style={[
                styles.segment,
                active ? styles.segmentActive : styles.segmentInactive,
            ]}
        >
            <Text style={[styles.segmentText, active && styles.segmentTextActive]}>
                {label}
            </Text>
        </Pressable>
    );
}

const styles = StyleSheet.create({
    header: {
        flexDirection: "row",
        gap: 12,
        alignItems: "center",
        marginBottom: 16,
    },
    title: {
        color: theme.colors.gold2,
        fontSize: 32,
        fontWeight: "900",
    },
    subtitle: {
        color: theme.colors.textSoft,
        marginTop: 6,
        lineHeight: 21,
    },
    caseImage: {
        width: 86,
        height: 86,
        resizeMode: "contain",
    },
    noticeTitle: {
        color: theme.colors.gold2,
        fontSize: 18,
        fontWeight: "900",
    },
    noticeText: {
        color: theme.colors.textSoft,
        marginTop: 8,
        lineHeight: 21,
    },
    sectionLabel: {
        color: theme.colors.gold2,
        fontSize: 12,
        fontWeight: "800",
        letterSpacing: 1.2,
        textTransform: "uppercase",
    },
    segmentRow: {
        flexDirection: "row",
        gap: 10,
        marginTop: 10,
    },
    segment: {
        flex: 1,
        minHeight: 46,
        borderRadius: theme.radius.pill,
        alignItems: "center",
        justifyContent: "center",
        borderWidth: 1.2,
    },
    segmentActive: {
        backgroundColor: "rgba(214,179,106,0.18)",
        borderColor: theme.colors.borderStrong,
    },
    segmentInactive: {
        backgroundColor: "rgba(255,255,255,0.02)",
        borderColor: theme.colors.border,
    },
    segmentText: {
        color: theme.colors.textSoft,
        fontWeight: "800",
    },
    segmentTextActive: {
        color: theme.colors.gold2,
    },
    chipRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        gap: 12,
    },
    chipLeft: {
        flexDirection: "row",
        alignItems: "center",
        gap: 12,
        flex: 1,
    },
    chipImage: {
        width: 52,
        height: 52,
        resizeMode: "contain",
    },
    chipName: {
        color: theme.colors.text,
        fontSize: 16,
        fontWeight: "800",
    },
    chipValue: {
        color: theme.colors.textSoft,
        marginTop: 2,
    },
    chipInput: {
        width: 78,
        minHeight: 46,
        borderRadius: theme.radius.pill,
        borderWidth: 1.2,
        borderColor: theme.colors.borderStrong,
        backgroundColor: "rgba(214,179,106,0.06)",
        color: theme.colors.text,
        textAlign: "center",
        fontSize: 16,
        fontWeight: "800",
    },
    totalBox: {
        marginTop: 6,
        borderRadius: theme.radius.md,
        borderWidth: 1.2,
        borderColor: theme.colors.borderStrong,
        backgroundColor: "rgba(214,179,106,0.08)",
        padding: 14,
    },
    totalLabel: {
        color: theme.colors.gold2,
        fontSize: 11,
        fontWeight: "800",
        letterSpacing: 1.1,
        textTransform: "uppercase",
    },
    totalValue: {
        color: theme.colors.text,
        fontSize: 24,
        fontWeight: "900",
        marginTop: 6,
    },
    actionStack: {
        marginTop: 18,
        gap: 12,
    },
});