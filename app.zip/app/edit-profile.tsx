import { useCallback, useState } from "react";
import { Alert, Image, StyleSheet, Text, View } from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import * as ImagePicker from "expo-image-picker";
import ScreenContainer from "../src/components/ScreenContainer";
import ThemedCard from "../src/components/ThemedCard";
import ThemedButton from "../src/components/ThemedButton";
import LuxuryInput from "../src/components/LuxuryInput";
import { api } from "../src/lib/api";
import { useAuth } from "../src/context/AuthContext";
import { theme } from "../src/theme/theme";

const coinImage = require("../assets/images/doubleo-coin.png");

type UserRow = {
  id: number;
  username: string;
  profile_image_base64: string | null;
};

export default function EditProfileScreen() {
  const router = useRouter();
  const { user, refreshMe } = useAuth();

  const [profile, setProfile] = useState<UserRow | null>(null);
  const [username, setUsername] = useState("");
  const [profileImageBase64, setProfileImageBase64] = useState<string | null>(null);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);

  async function loadProfile() {
    const usersRes = await api.get("/users");
    const me = usersRes.data.find((item: UserRow) => item.id === user?.id) || null;
    setProfile(me);
    setUsername(me?.username || "");
    setProfileImageBase64(null);
  }

  useFocusEffect(
    useCallback(() => {
      loadProfile().catch(() => {});
    }, []),
  );

  async function pickImage() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permission.granted) {
      Alert.alert("Permission needed", "Please allow gallery access.");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsEditing: true,
      quality: 0.8,
      base64: true,
      aspect: [1, 1],
    });

    if (!result.canceled && result.assets[0]?.base64) {
      setProfileImageBase64(result.assets[0].base64);
    }
  }

  async function saveProfile() {
    try {
      setSavingProfile(true);
      await api.patch("/users/me/profile", {
        username: username.trim(),
        profileImageBase64: profileImageBase64 || undefined,
      });

      await refreshMe();
      await loadProfile();
      Alert.alert("Saved", "Profile updated successfully.");
    } catch (error: any) {
      Alert.alert("Error", error?.response?.data?.message || "Failed to update profile");
    } finally {
      setSavingProfile(false);
    }
  }

  async function savePassword() {
    try {
      setSavingPassword(true);
      await api.post("/users/me/password", {
        currentPassword,
        newPassword,
        confirmNewPassword,
      });

      setCurrentPassword("");
      setNewPassword("");
      setConfirmNewPassword("");
      Alert.alert("Saved", "Password changed successfully.");
    } catch (error: any) {
      Alert.alert("Error", error?.response?.data?.message || "Failed to change password");
    } finally {
      setSavingPassword(false);
    }
  }

  const profileUri = profileImageBase64
    ? `data:image/jpeg;base64,${profileImageBase64}`
    : profile?.profile_image_base64
      ? `data:image/jpeg;base64,${profile.profile_image_base64}`
      : null;

  return (
    <ScreenContainer>
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>Edit Profile</Text>
          <Text style={styles.subtitle}>Change your username, password and picture in one dedicated place.</Text>
        </View>
        <Image source={coinImage} style={styles.coin} />
      </View>

      <ThemedCard glow="gold" style={styles.cardSpacing}>
        <View style={styles.avatarWrap}>
          {profileUri ? (
            <Image source={{ uri: profileUri }} style={styles.avatar} />
          ) : (
            <View style={styles.avatarFallback}>
              <Text style={styles.avatarFallbackText}>O²</Text>
            </View>
          )}
        </View>

        <View style={{ marginTop: 14 }}>
          <LuxuryInput
            label="Username"
            placeholder="Username"
            value={username}
            onChangeText={setUsername}
            autoCapitalize="none"
          />
        </View>

        <View style={styles.buttonStack}>
          <ThemedButton title="Choose New Photo" variant="dark" onPress={pickImage} />
          <ThemedButton
            title={savingProfile ? "Saving..." : "Save Profile"}
            onPress={saveProfile}
            loading={savingProfile}
          />
        </View>
      </ThemedCard>

      <ThemedCard glow="none" style={styles.cardSpacing}>
        <Text style={styles.sectionTitle}>Change Password</Text>

        <LuxuryInput
          label="Current Password"
          placeholder="Current password"
          secureTextEntry
          value={currentPassword}
          onChangeText={setCurrentPassword}
        />
        <View style={{ height: 12 }} />
        <LuxuryInput
          label="New Password"
          placeholder="New password"
          secureTextEntry
          value={newPassword}
          onChangeText={setNewPassword}
        />
        <View style={{ height: 12 }} />
        <LuxuryInput
          label="Confirm New Password"
          placeholder="Confirm new password"
          secureTextEntry
          value={confirmNewPassword}
          onChangeText={setConfirmNewPassword}
        />

        <View style={styles.buttonStack}>
          <ThemedButton
            title={savingPassword ? "Saving..." : "Update Password"}
            onPress={savePassword}
            loading={savingPassword}
          />
          <ThemedButton title="Back to Profile" variant="ghost" onPress={() => router.back()} />
        </View>
      </ThemedCard>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 16,
  },
  title: {
    color: theme.colors.gold2,
    fontSize: 32,
    fontWeight: "900",
  },
  subtitle: {
    color: theme.colors.textSoft,
    marginTop: 6,
    lineHeight: 21,
  },
  coin: {
    width: 72,
    height: 72,
  },
  cardSpacing: {
    marginBottom: 18,
  },
  avatarWrap: {
    alignSelf: "center",
    width: 112,
    height: 112,
    borderRadius: 56,
    padding: 4,
    borderWidth: 1.4,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.12)",
  },
  avatar: {
    width: "100%",
    height: "100%",
    borderRadius: 52,
  },
  avatarFallback: {
    flex: 1,
    borderRadius: 52,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(214,179,106,0.12)",
  },
  avatarFallbackText: {
    color: theme.colors.gold2,
    fontSize: 34,
    fontWeight: "900",
  },
  sectionTitle: {
    color: theme.colors.gold2,
    fontSize: 20,
    fontWeight: "900",
    marginBottom: 12,
  },
  buttonStack: {
    gap: 12,
    marginTop: 16,
  },
});
