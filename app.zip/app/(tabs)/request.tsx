import { useCallback, useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";
import { Redirect, useFocusEffect } from "expo-router";
import ScreenContainer from "../../src/components/ScreenContainer";
import ThemedCard from "../../src/components/ThemedCard";
import ThemedButton from "../../src/components/ThemedButton";
import { api } from "../../src/lib/api";
import { formatAmount, formatDateTime, theme } from "../../src/theme/theme";
import { useAuth } from "../../src/context/AuthContext";

type PendingRequest = {
  id: number;
  username: string;
  type: "TO_CHIPS" | "TO_COINS";
  amount_total: number;
  created_at: string;
};

export default function RequestQueueScreen() {
  const { user } = useAuth();
  const [requests, setRequests] = useState<PendingRequest[]>([]);
  const [loadingId, setLoadingId] = useState<number | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  async function loadRequests() {
    const response = await api.get("/conversion-requests/pending");
    setRequests(response.data);
  }

  async function onRefresh() {
    try {
      setRefreshing(true);
      await loadRequests();
    } finally {
      setRefreshing(false);
    }
  }

  async function approveRequest(id: number) {
    try {
      setLoadingId(id);
      await api.post(`/conversion-requests/${id}/approve`);
      await loadRequests();
    } catch (error: any) {
      Alert.alert("Error", error?.response?.data?.message || "Failed to approve request");
    } finally {
      setLoadingId(null);
    }
  }

  async function rejectRequest(id: number) {
    try {
      setLoadingId(id);
      await api.post(`/conversion-requests/${id}/reject`);
      await loadRequests();
    } catch (error: any) {
      Alert.alert("Error", error?.response?.data?.message || "Failed to reject request");
    } finally {
      setLoadingId(null);
    }
  }

  useFocusEffect(
    useCallback(() => {
      loadRequests().catch(() => {});
    }, []),
  );

  if (user?.role !== "ADMIN") {
    return <Redirect href="/(tabs)/profile" />;
  }

  return (
    <ScreenContainer refreshing={refreshing} onRefresh={onRefresh}>
      <Text style={styles.title}>Request Queue</Text>
      <Text style={styles.subtitle}>Approve or reject pending buy-ins and cash-outs from one place.</Text>

      <ThemedCard glow="gold" style={styles.summaryCard}>
        <Text style={styles.summaryLabel}>Pending now</Text>
        <Text style={styles.summaryValue}>{requests.length}</Text>
      </ThemedCard>

      <View style={styles.stack}>
        {requests.map((item) => (
          <ThemedCard key={item.id} glow="none">
            <View style={styles.topRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.memberName}>{item.username}</Text>
                <Text style={styles.requestType}>
                  {item.type === "TO_CHIPS" ? "Buy In" : "Cash Out"}
                </Text>
              </View>
              <Text style={styles.amount}>{formatAmount(item.amount_total)}</Text>
            </View>

            <Text style={styles.date}>{formatDateTime(item.created_at)}</Text>

            <View style={styles.buttonRow}>
              <ThemedButton
                title={loadingId === item.id ? "Working..." : "Approve"}
                onPress={() => approveRequest(item.id)}
                loading={loadingId === item.id}
              />
              <ThemedButton
                title="Reject"
                variant="dark"
                onPress={() => rejectRequest(item.id)}
                disabled={loadingId === item.id}
              />
            </View>
          </ThemedCard>
        ))}

        {requests.length === 0 ? (
          <ThemedCard glow="none">
            <Text style={styles.empty}>No pending requests.</Text>
          </ThemedCard>
        ) : null}
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  title: {
    color: theme.colors.gold2,
    fontSize: 32,
    fontWeight: "900",
  },
  subtitle: {
    color: theme.colors.textSoft,
    marginTop: 6,
    marginBottom: 16,
  },
  summaryCard: {
    marginBottom: 16,
    alignItems: "center",
  },
  summaryLabel: {
    color: theme.colors.textSoft,
    textTransform: "uppercase",
    letterSpacing: 1.1,
    fontWeight: "700",
    fontSize: 12,
  },
  summaryValue: {
    color: theme.colors.gold2,
    fontSize: 34,
    fontWeight: "900",
    marginTop: 6,
  },
  stack: {
    gap: 12,
  },
  topRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
    alignItems: "center",
  },
  memberName: {
    color: theme.colors.text,
    fontSize: 20,
    fontWeight: "900",
  },
  requestType: {
    color: theme.colors.textSoft,
    marginTop: 4,
  },
  amount: {
    color: theme.colors.gold2,
    fontSize: 24,
    fontWeight: "900",
  },
  date: {
    color: theme.colors.muted,
    marginTop: 10,
    marginBottom: 16,
  },
  buttonRow: {
    gap: 10,
  },
  empty: {
    color: theme.colors.textSoft,
    textAlign: "center",
  },
});
