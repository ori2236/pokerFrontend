import { useCallback, useMemo, useState } from "react";
import { Alert, Image, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import ScreenContainer from "../../src/components/ScreenContainer";
import ThemedCard from "../../src/components/ThemedCard";
import ThemedButton from "../../src/components/ThemedButton";
import LuxuryInput from "../../src/components/LuxuryInput";
import { api } from "../../src/lib/api";
import { useAuth } from "../../src/context/AuthContext";
import { formatAmount, theme } from "../../src/theme/theme";

const coinImage = require("../../assets/images/doubleo-coin.png");
const whiteChip = require("../../assets/chips/white.png");
const redChip = require("../../assets/chips/red.png");
const blueChip = require("../../assets/chips/blue.png");
const greenChip = require("../../assets/chips/green.png");
const blackChip = require("../../assets/chips/black.png");

type ChipKey = "white" | "red" | "blue" | "green" | "black";
type ChipCounts = Record<ChipKey, number>;
type InputMode = "TOTAL_AMOUNT" | "CHIP_BREAKDOWN";

type SessionPlayer = {
  user_id: number;
  username: string;
  profile_image_base64?: string | null;
  is_playing: boolean;
};

type PendingRequest = {
  id: number;
  user_id: number;
  username: string;
  type: "TO_CHIPS" | "TO_COINS";
  amount_total: number;
};

type ActiveSession = {
  id: number;
  title: string;
  players: SessionPlayer[];
  pendingRequests: PendingRequest[];
  myPendingRequest: null | {
    id: number;
    type: "TO_CHIPS" | "TO_COINS";
    amount_total: number;
    status: "PENDING";
  };
};

type LeaderboardEntry = {
  rank: number;
  id: number;
  username: string;
  balance: number;
  profile_image_base64?: string | null;
};

const chipConfig: Array<{ key: ChipKey; label: string; value: number; image: any }> = [
  { key: "white", label: "White", value: 1, image: whiteChip },
  { key: "red", label: "Red", value: 5, image: redChip },
  { key: "blue", label: "Blue", value: 10, image: blueChip },
  { key: "green", label: "Green", value: 25, image: greenChip },
  { key: "black", label: "Black", value: 50, image: blackChip },
];

export default function SessionScreen() {
  const router = useRouter();
  const { user } = useAuth();

  const [activeSession, setActiveSession] = useState<ActiveSession | null>(null);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [sessionTitle, setSessionTitle] = useState("");
  const [adminStartMode, setAdminStartMode] = useState<InputMode>("TOTAL_AMOUNT");
  const [adminEndMode, setAdminEndMode] = useState<InputMode>("TOTAL_AMOUNT");
  const [playerBuyInMode, setPlayerBuyInMode] = useState<InputMode>("TOTAL_AMOUNT");
  const [adminStartAmount, setAdminStartAmount] = useState("");
  const [adminEndAmount, setAdminEndAmount] = useState("");
  const [playerBuyInAmount, setPlayerBuyInAmount] = useState("");
  const [adminStartChips, setAdminStartChips] = useState<ChipCounts>(emptyChips());
  const [adminEndChips, setAdminEndChips] = useState<ChipCounts>(emptyChips());
  const [playerBuyInChips, setPlayerBuyInChips] = useState<ChipCounts>(emptyChips());
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [buyInSubmitting, setBuyInSubmitting] = useState(false);

  async function loadData() {
    const [sessionRes, leaderboardRes] = await Promise.all([
      api.get("/sessions/active"),
      api.get("/balances/leaderboard"),
    ]);

    setActiveSession(sessionRes.data.activeSession);
    setLeaderboard(leaderboardRes.data);
  }

  async function onRefresh() {
    try {
      setRefreshing(true);
      await loadData();
    } finally {
      setRefreshing(false);
    }
  }

  useFocusEffect(
    useCallback(() => {
      loadData().catch(() => {});
    }, []),
  );

  const myPlayer = activeSession?.players.find((p) => p.user_id === user?.id) || null;
  const amIPlaying = !!myPlayer?.is_playing;
  const myPending = activeSession?.myPendingRequest || null;
  const activeCount = activeSession?.players.filter((p) => p.is_playing).length || 0;
  const top3 = leaderboard.slice(0, 3);
  const isAdmin = user?.role === "ADMIN";

  async function startSession() {
    try {
      if (!sessionTitle.trim()) {
        Alert.alert("Missing title", "Enter a session title.");
        return;
      }

      const payload = buildPayload({
        mode: adminStartMode,
        amount: adminStartAmount,
        chips: adminStartChips,
        requirePositive: true,
      });

      if (!payload) {
        Alert.alert("Invalid buy in", "Enter a valid admin buy-in.");
        return;
      }

      setLoading(true);
      await api.post("/sessions/start", {
        title: sessionTitle.trim(),
        ...payload,
      });
      setSessionTitle("");
      setAdminStartAmount("");
      setAdminStartChips(emptyChips());
      await loadData();
    } catch (error: any) {
      Alert.alert("Error", error?.response?.data?.message || "Failed to start session");
    } finally {
      setLoading(false);
    }
  }

  async function endSession() {
    try {
      const payload = buildPayload({
        mode: adminEndMode,
        amount: adminEndAmount,
        chips: adminEndChips,
        requirePositive: false,
      });

      if (!payload) {
        Alert.alert("Invalid cash out", "Enter a valid admin cash-out.");
        return;
      }

      setLoading(true);
      await api.post("/sessions/active/end", payload);
      setAdminEndAmount("");
      setAdminEndChips(emptyChips());
      await loadData();
    } catch (error: any) {
      Alert.alert("Error", error?.response?.data?.message || "Failed to end session");
    } finally {
      setLoading(false);
    }
  }

  async function createBuyInRequest() {
    try {
      const payload = buildPayload({
        mode: playerBuyInMode,
        amount: playerBuyInAmount,
        chips: playerBuyInChips,
        requirePositive: true,
      });

      if (!payload) {
        Alert.alert("Invalid buy in", "Enter a valid buy-in amount.");
        return;
      }

      setBuyInSubmitting(true);
      await api.post("/conversion-requests", {
        type: "TO_CHIPS",
        ...payload,
      });

      setPlayerBuyInAmount("");
      setPlayerBuyInChips(emptyChips());
      await loadData();
      Alert.alert("Request sent", "Your buy-in request is waiting for admin approval.");
    } catch (error: any) {
      Alert.alert("Error", error?.response?.data?.message || "Failed to create request");
    } finally {
      setBuyInSubmitting(false);
    }
  }

  return (
    <ScreenContainer refreshing={refreshing} onRefresh={onRefresh}>
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>{activeSession ? activeSession.title : "Session"}</Text>
          <Text style={styles.subtitle}>
            {activeSession
              ? "Manage the live table, requests and current leaders from one premium screen."
              : isAdmin
                ? "Open the next table directly from here."
                : "Wait for the admin to open the next session."}
          </Text>
        </View>
        <Image source={coinImage} style={styles.coin} />
      </View>

      <ThemedCard glow="gold" style={styles.heroCard}>
        <View style={styles.metricsRow}>
          <MetricBox label="At Table" value={String(activeCount)} />
          <MetricBox label="Awaiting Admin" value={String(activeSession?.pendingRequests.length || 0)} />
        </View>

        {activeSession ? (
          isAdmin ? (
            <View style={{ marginTop: 16 }}>
              <Text style={styles.cardTitle}>Close Session</Text>
              <Text style={styles.helpText}>
                Enter your own cash out, then close the session. Players still at the table will be removed automatically.
              </Text>
              <AmountEditor
                mode={adminEndMode}
                setMode={setAdminEndMode}
                amount={adminEndAmount}
                setAmount={setAdminEndAmount}
                chips={adminEndChips}
                setChips={setAdminEndChips}
                amountLabel="Admin cash out"
              />
              <View style={{ marginTop: 16 }}>
                <ThemedButton
                  title={loading ? "Ending..." : "End Session"}
                  onPress={endSession}
                  loading={loading}
                />
              </View>
            </View>
          ) : myPending ? (
            <View style={{ marginTop: 16 }}>
              <Text style={styles.cardTitle}>Awaiting Admin</Text>
              <Text style={styles.helpText}>
                {myPending.type === "TO_CHIPS"
                  ? "Your buy-in request is waiting for approval."
                  : "Your cash out request is waiting for approval. You remain in the session until it is approved."}
              </Text>
            </View>
          ) : amIPlaying ? (
            <View style={{ marginTop: 16 }}>
              <Text style={styles.cardTitle}>Leave the Table</Text>
              <Text style={styles.helpText}>When you are ready to leave, submit your cash-out request.</Text>
              <View style={{ marginTop: 16 }}>
                <ThemedButton title="Request Cash Out" onPress={() => router.push("/cashout?fromSession=1")} />
              </View>
            </View>
          ) : (
            <View style={{ marginTop: 16 }}>
              <Text style={styles.cardTitle}>Join the Table</Text>
              <Text style={styles.helpText}>Regular users now request buy-in directly from the Session screen.</Text>
              <AmountEditor
                mode={playerBuyInMode}
                setMode={setPlayerBuyInMode}
                amount={playerBuyInAmount}
                setAmount={setPlayerBuyInAmount}
                chips={playerBuyInChips}
                setChips={setPlayerBuyInChips}
                amountLabel="Buy in amount"
              />
              <View style={{ marginTop: 16 }}>
                <ThemedButton
                  title={buyInSubmitting ? "Sending..." : "Request Buy In"}
                  onPress={createBuyInRequest}
                  loading={buyInSubmitting}
                />
              </View>
            </View>
          )
        ) : isAdmin ? (
          <View style={{ marginTop: 16 }}>
            <Text style={styles.cardTitle}>Open a New Session</Text>
            <LuxuryInput
              label="Session title"
              placeholder="Friday Night Table"
              value={sessionTitle}
              onChangeText={setSessionTitle}
            />
            <View style={{ marginTop: 14 }}>
              <Text style={styles.helpLabel}>Admin buy in</Text>
              <Text style={styles.helpText}>The admin must enter the session with a real buy-in like everyone else.</Text>
            </View>
            <AmountEditor
              mode={adminStartMode}
              setMode={setAdminStartMode}
              amount={adminStartAmount}
              setAmount={setAdminStartAmount}
              chips={adminStartChips}
              setChips={setAdminStartChips}
              amountLabel="Admin buy in"
            />
            <View style={{ marginTop: 16 }}>
              <ThemedButton
                title={loading ? "Starting..." : "Start Session"}
                onPress={startSession}
                loading={loading}
              />
            </View>
          </View>
        ) : (
          <View style={{ marginTop: 16 }}>
            <Text style={styles.cardTitle}>No Active Session</Text>
            <Text style={styles.helpText}>The table is closed until the admin opens a new session.</Text>
          </View>
        )}
      </ThemedCard>

      <Text style={styles.sectionTitle}>Podium</Text>
      <CasinoPodium top3={top3} />

      <Text style={styles.sectionTitle}>Players</Text>
      <View style={styles.stack}>
        {(activeSession?.players || []).map((player) => (
          <ThemedCard key={player.user_id} glow="none">
            <View style={styles.playerRow}>
              <View style={styles.playerIdentity}>
                {player.profile_image_base64 ? (
                  <Image
                    source={{ uri: `data:image/jpeg;base64,${player.profile_image_base64}` }}
                    style={styles.playerAvatar}
                  />
                ) : (
                  <View style={styles.playerAvatarFallback}>
                    <Text style={styles.playerAvatarFallbackText}>{player.username.slice(0, 1).toUpperCase()}</Text>
                  </View>
                )}
                <Text style={styles.playerName}>{player.username}</Text>
              </View>
              <View style={[styles.stateBadge, player.is_playing ? styles.badgeIn : styles.badgeOut]}>
                <Text
                  style={[
                    styles.stateBadgeText,
                    { color: player.is_playing ? theme.colors.success : theme.colors.textSoft },
                  ]}
                >
                  {player.is_playing ? "IN" : "OUT"}
                </Text>
              </View>
            </View>
          </ThemedCard>
        ))}

        {!activeSession ? (
          <ThemedCard glow="none">
            <Text style={styles.empty}>No active players right now.</Text>
          </ThemedCard>
        ) : null}
      </View>
    </ScreenContainer>
  );
}

function AmountEditor({
  mode,
  setMode,
  amount,
  setAmount,
  chips,
  setChips,
  amountLabel,
}: {
  mode: InputMode;
  setMode: (value: InputMode) => void;
  amount: string;
  setAmount: (value: string) => void;
  chips: ChipCounts;
  setChips: (value: ChipCounts) => void;
  amountLabel: string;
}) {
  const totalFromChips =
    chips.white * 1 +
    chips.red * 5 +
    chips.blue * 10 +
    chips.green * 25 +
    chips.black * 50;

  function updateChip(key: ChipKey, value: string) {
    const numeric = Math.max(0, Number(value.replace(/[^0-9]/g, "") || 0));
    setChips({ ...chips, [key]: numeric });
  }

  return (
    <View style={{ marginTop: 14 }}>
      <View style={styles.segmentRow}>
        <Segment active={mode === "TOTAL_AMOUNT"} label="Amount" onPress={() => setMode("TOTAL_AMOUNT")} />
        <Segment active={mode === "CHIP_BREAKDOWN"} label="Chips" onPress={() => setMode("CHIP_BREAKDOWN")} />
      </View>

      {mode === "TOTAL_AMOUNT" ? (
        <View style={{ marginTop: 14 }}>
          <LuxuryInput
            label={amountLabel}
            placeholder="Enter amount"
            keyboardType="numeric"
            value={amount}
            onChangeText={setAmount}
          />
        </View>
      ) : (
        <View style={{ marginTop: 14, gap: 12 }}>
          {chipConfig.map((chip) => (
            <View key={chip.key} style={styles.chipRow}>
              <View style={styles.chipLeft}>
                <Image source={chip.image} style={styles.chipImage} />
                <View>
                  <Text style={styles.chipName}>{chip.label}</Text>
                  <Text style={styles.chipValue}>Value: {chip.value}</Text>
                </View>
              </View>

              <TextInput
                value={chips[chip.key] ? String(chips[chip.key]) : ""}
                onChangeText={(value) => updateChip(chip.key, value)}
                keyboardType="numeric"
                placeholder="0"
                placeholderTextColor={theme.colors.muted}
                style={styles.chipInput}
              />
            </View>
          ))}

          <View style={styles.totalBox}>
            <Text style={styles.totalLabel}>Calculated total</Text>
            <Text style={styles.totalValue}>{formatAmount(totalFromChips)} O²</Text>
          </View>
        </View>
      )}
    </View>
  );
}

function Segment({
  active,
  label,
  onPress,
}: {
  active: boolean;
  label: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={[styles.segment, active ? styles.segmentActive : styles.segmentInactive]}
    >
      <Text style={[styles.segmentText, active && styles.segmentTextActive]}>{label}</Text>
    </Pressable>
  );
}

function MetricBox({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.metricBox}>
      <Text style={styles.metricLabel}>{label}</Text>
      <Text style={styles.metricValue}>{value}</Text>
    </View>
  );
}

function CasinoPodium({ top3 }: { top3: LeaderboardEntry[] }) {
  const silver = top3[1] || null;
  const gold = top3[0] || null;
  const bronze = top3[2] || null;

  return (
    <ThemedCard glow="gold" style={styles.podiumShell}>
      <View style={styles.podiumStage}>
        <PodiumColumn entry={silver} place={2} height={118} />
        <PodiumColumn entry={gold} place={1} height={164} featured />
        <PodiumColumn entry={bronze} place={3} height={96} />
      </View>
    </ThemedCard>
  );
}

function PodiumColumn({
  entry,
  place,
  height,
  featured = false,
}: {
  entry: LeaderboardEntry | null;
  place: 1 | 2 | 3;
  height: number;
  featured?: boolean;
}) {
  if (!entry) {
    return <View style={{ flex: 1 }} />;
  }

  const avatarUri = entry.profile_image_base64 ? `data:image/jpeg;base64,${entry.profile_image_base64}` : null;

  return (
    <View style={styles.podiumColumnWrap}>
      {avatarUri ? (
        <Image source={{ uri: avatarUri }} style={[styles.podiumAvatar, featured && styles.podiumAvatarFeatured]} />
      ) : (
        <View style={[styles.podiumAvatarFallback, featured && styles.podiumAvatarFeatured]}>
          <Text style={styles.podiumAvatarFallbackText}>{entry.username.slice(0, 1).toUpperCase()}</Text>
        </View>
      )}
      <Text style={styles.podiumName}>{entry.username}</Text>
      <Text style={styles.podiumBalance}>{formatAmount(entry.balance)} O²</Text>
      <View style={[styles.podiumBlock, { height }, featured && styles.podiumBlockFeatured]}>
        <Text style={styles.podiumPlace}>{place}</Text>
      </View>
    </View>
  );
}

function emptyChips(): ChipCounts {
  return {
    white: 0,
    red: 0,
    blue: 0,
    green: 0,
    black: 0,
  };
}

function buildPayload({
  mode,
  amount,
  chips,
  requirePositive,
}: {
  mode: InputMode;
  amount: string;
  chips: ChipCounts;
  requirePositive: boolean;
}) {
  if (mode === "TOTAL_AMOUNT") {
    if (amount === "" || Number.isNaN(Number(amount)) || Number(amount) < 0) {
      return null;
    }

    if (requirePositive && Number(amount) <= 0) {
      return null;
    }

    return {
      amount_mode: "TOTAL_AMOUNT" as const,
      amount_total: Number(amount),
    };
  }

  const total =
    chips.white * 1 +
    chips.red * 5 +
    chips.blue * 10 +
    chips.green * 25 +
    chips.black * 50;

  if (requirePositive && total <= 0) {
    return null;
  }

  return {
    amount_mode: "CHIP_BREAKDOWN" as const,
    white_count: chips.white,
    red_count: chips.red,
    blue_count: chips.blue,
    green_count: chips.green,
    black_count: chips.black,
  };
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
    gap: 12,
  },
  title: {
    color: theme.colors.gold2,
    fontSize: 32,
    fontWeight: "900",
  },
  subtitle: {
    color: theme.colors.textSoft,
    marginTop: 6,
    lineHeight: 21,
  },
  coin: {
    width: 72,
    height: 72,
  },
  heroCard: {
    marginBottom: 18,
  },
  metricsRow: {
    flexDirection: "row",
    gap: 10,
  },
  metricBox: {
    flex: 1,
    borderRadius: theme.radius.md,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.07)",
    padding: 12,
    alignItems: "center",
  },
  metricLabel: {
    color: theme.colors.gold2,
    fontSize: 11,
    fontWeight: "800",
    textTransform: "uppercase",
    letterSpacing: 1,
  },
  metricValue: {
    color: theme.colors.text,
    fontSize: 24,
    fontWeight: "900",
    marginTop: 6,
  },
  cardTitle: {
    color: theme.colors.gold2,
    fontSize: 20,
    fontWeight: "900",
  },
  helpLabel: {
    color: theme.colors.gold2,
    fontSize: 14,
    fontWeight: "800",
  },
  helpText: {
    color: theme.colors.textSoft,
    marginTop: 8,
    lineHeight: 21,
  },
  sectionTitle: {
    color: theme.colors.gold2,
    fontSize: 22,
    fontWeight: "900",
    marginBottom: 12,
  },
  podiumShell: {
    marginBottom: 18,
  },
  podiumStage: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    gap: 10,
  },
  podiumColumnWrap: {
    flex: 1,
    alignItems: "center",
  },
  podiumAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    marginBottom: 8,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
  },
  podiumAvatarFallback: {
    width: 56,
    height: 56,
    borderRadius: 28,
    marginBottom: 8,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.12)",
    alignItems: "center",
    justifyContent: "center",
  },
  podiumAvatarFeatured: {
    width: 64,
    height: 64,
    borderRadius: 32,
  },
  podiumAvatarFallbackText: {
    color: theme.colors.gold2,
    fontWeight: "900",
    fontSize: 24,
  },
  podiumName: {
    color: theme.colors.text,
    fontWeight: "800",
    fontSize: 14,
    textAlign: "center",
  },
  podiumBalance: {
    color: theme.colors.textSoft,
    marginTop: 4,
    marginBottom: 8,
    fontSize: 12,
    textAlign: "center",
  },
  podiumBlock: {
    width: "100%",
    borderTopLeftRadius: theme.radius.lg,
    borderTopRightRadius: theme.radius.lg,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.10)",
    alignItems: "center",
    justifyContent: "center",
  },
  podiumBlockFeatured: {
    backgroundColor: "rgba(214,179,106,0.18)",
  },
  podiumPlace: {
    color: theme.colors.gold2,
    fontSize: 34,
    fontWeight: "900",
  },
  segmentRow: {
    flexDirection: "row",
    gap: 10,
  },
  segment: {
    flex: 1,
    minHeight: 42,
    borderRadius: theme.radius.pill,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1.2,
  },
  segmentActive: {
    backgroundColor: "rgba(214,179,106,0.18)",
    borderColor: theme.colors.borderStrong,
  },
  segmentInactive: {
    backgroundColor: "rgba(255,255,255,0.02)",
    borderColor: theme.colors.border,
  },
  segmentText: {
    color: theme.colors.textSoft,
    fontWeight: "800",
    fontSize: 12,
  },
  segmentTextActive: {
    color: theme.colors.gold2,
  },
  chipRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
  },
  chipLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    flex: 1,
  },
  chipImage: {
    width: 52,
    height: 52,
    resizeMode: "contain",
  },
  chipName: {
    color: theme.colors.text,
    fontSize: 16,
    fontWeight: "800",
  },
  chipValue: {
    color: theme.colors.textSoft,
    marginTop: 2,
  },
  chipInput: {
    width: 78,
    minHeight: 46,
    borderRadius: theme.radius.pill,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.06)",
    color: theme.colors.text,
    textAlign: "center",
    fontSize: 16,
    fontWeight: "800",
  },
  totalBox: {
    borderRadius: theme.radius.md,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.08)",
    padding: 14,
    alignItems: "center",
  },
  totalLabel: {
    color: theme.colors.textSoft,
    fontSize: 12,
    fontWeight: "700",
    textTransform: "uppercase",
    letterSpacing: 1,
  },
  totalValue: {
    color: theme.colors.gold2,
    fontSize: 24,
    fontWeight: "900",
    marginTop: 6,
  },
  stack: {
    gap: 12,
  },
  playerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
  },
  playerIdentity: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    flex: 1,
  },
  playerAvatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
  },
  playerAvatarFallback: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: "rgba(214,179,106,0.12)",
    alignItems: "center",
    justifyContent: "center",
  },
  playerAvatarFallbackText: {
    color: theme.colors.gold2,
    fontWeight: "900",
  },
  playerName: {
    color: theme.colors.text,
    fontSize: 18,
    fontWeight: "900",
    flexShrink: 1,
  },
  stateBadge: {
    borderRadius: theme.radius.pill,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },
  badgeIn: {
    backgroundColor: "rgba(88,211,155,0.14)",
  },
  badgeOut: {
    backgroundColor: "rgba(255,255,255,0.06)",
  },
  stateBadgeText: {
    fontWeight: "900",
    letterSpacing: 0.7,
  },
  empty: {
    color: theme.colors.textSoft,
    textAlign: "center",
  },
});
