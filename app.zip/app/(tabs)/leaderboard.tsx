import { useCallback, useMemo, useState } from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { useFocusEffect } from "expo-router";
import ScreenContainer from "../../src/components/ScreenContainer";
import ThemedCard from "../../src/components/ThemedCard";
import { api } from "../../src/lib/api";
import { formatAmount, theme } from "../../src/theme/theme";

const coinImage = require("../../assets/images/doubleo-coin.png");

type Entry = {
  rank: number;
  id: number;
  username: string;
  balance: number;
  profile_image_base64?: string | null;
};

export default function LeaderboardScreen() {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  async function loadData() {
    const response = await api.get("/balances/leaderboard");
    setEntries(response.data);
  }

  async function onRefresh() {
    try {
      setRefreshing(true);
      await loadData();
    } finally {
      setRefreshing(false);
    }
  }

  useFocusEffect(
    useCallback(() => {
      loadData().catch(() => {});
    }, []),
  );

  const top3 = useMemo(() => entries.slice(0, 3), [entries]);
  const fullList = useMemo(() => entries, [entries]);

  return (
    <ScreenContainer refreshing={refreshing} onRefresh={onRefresh}>
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>Leaderboard</Text>
          <Text style={styles.subtitle}>A cleaner ranking table with a casino-style podium and a tighter full list.</Text>
        </View>
        <Image source={coinImage} style={styles.coin} />
      </View>

      <CasinoPodium top3={top3} />

      <Text style={styles.sectionTitle}>Full Ranking</Text>
      <View style={styles.stack}>
        {fullList.map((entry) => {
          const avatarUri = entry.profile_image_base64
            ? `data:image/jpeg;base64,${entry.profile_image_base64}`
            : null;

          return (
            <ThemedCard key={entry.id} glow={entry.rank <= 3 ? "gold" : "none"}>
              <View style={styles.row}>
                <View style={styles.leftGroup}>
                  <View style={styles.rankPill}>
                    <Text style={styles.rankText}>#{entry.rank}</Text>
                  </View>
                  {avatarUri ? (
                    <Image source={{ uri: avatarUri }} style={styles.avatar} />
                  ) : (
                    <View style={styles.avatarFallback}>
                      <Text style={styles.avatarFallbackText}>{entry.username.slice(0, 1).toUpperCase()}</Text>
                    </View>
                  )}
                  <Text style={styles.rowName}>{entry.username}</Text>
                </View>
                <Text style={styles.rowBalance}>{formatAmount(entry.balance)} O²</Text>
              </View>
            </ThemedCard>
          );
        })}

        {fullList.length === 0 ? (
          <ThemedCard glow="none">
            <Text style={styles.empty}>No leaderboard entries yet.</Text>
          </ThemedCard>
        ) : null}
      </View>
    </ScreenContainer>
  );
}

function CasinoPodium({ top3 }: { top3: Entry[] }) {
  const silver = top3[1] || null;
  const gold = top3[0] || null;
  const bronze = top3[2] || null;

  return (
    <ThemedCard glow="gold" style={styles.podiumShell}>
      <Text style={styles.podiumTitle}>Top 3</Text>

      <View style={styles.podiumStage}>
        <PodiumColumn entry={silver} place={2} height={118} />
        <PodiumColumn entry={gold} place={1} height={164} featured />
        <PodiumColumn entry={bronze} place={3} height={96} />
      </View>
    </ThemedCard>
  );
}

function PodiumColumn({
  entry,
  place,
  height,
  featured = false,
}: {
  entry: Entry | null;
  place: 1 | 2 | 3;
  height: number;
  featured?: boolean;
}) {
  if (!entry) {
    return <View style={{ flex: 1 }} />;
  }

  const avatarUri = entry.profile_image_base64 ? `data:image/jpeg;base64,${entry.profile_image_base64}` : null;

  return (
    <View style={styles.podiumColumnWrap}>
      {avatarUri ? (
        <Image source={{ uri: avatarUri }} style={[styles.podiumAvatar, featured && styles.podiumAvatarFeatured]} />
      ) : (
        <View style={[styles.podiumAvatarFallback, featured && styles.podiumAvatarFeatured]}>
          <Text style={styles.podiumAvatarFallbackText}>{entry.username.slice(0, 1).toUpperCase()}</Text>
        </View>
      )}
      <Text style={styles.podiumName}>{entry.username}</Text>
      <Text style={styles.podiumBalance}>{formatAmount(entry.balance)} O²</Text>
      <View style={[styles.podiumBlock, { height }, featured && styles.podiumBlockFeatured]}>
        <Text style={styles.podiumPlace}>{place}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  title: {
    color: theme.colors.gold2,
    fontSize: 34,
    fontWeight: "900",
  },
  subtitle: {
    color: theme.colors.textSoft,
    marginTop: 6,
    lineHeight: 21,
  },
  coin: {
    width: 72,
    height: 72,
  },
  podiumShell: {
    marginBottom: 18,
  },
  podiumTitle: {
    color: theme.colors.gold2,
    fontSize: 22,
    fontWeight: "900",
    marginBottom: 14,
    textAlign: "center",
  },
  podiumStage: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    gap: 10,
  },
  podiumColumnWrap: {
    flex: 1,
    alignItems: "center",
  },
  podiumAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    marginBottom: 8,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
  },
  podiumAvatarFallback: {
    width: 56,
    height: 56,
    borderRadius: 28,
    marginBottom: 8,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.12)",
    alignItems: "center",
    justifyContent: "center",
  },
  podiumAvatarFeatured: {
    width: 64,
    height: 64,
    borderRadius: 32,
  },
  podiumAvatarFallbackText: {
    color: theme.colors.gold2,
    fontWeight: "900",
    fontSize: 24,
  },
  podiumName: {
    color: theme.colors.text,
    fontWeight: "800",
    fontSize: 14,
    textAlign: "center",
  },
  podiumBalance: {
    color: theme.colors.textSoft,
    marginTop: 4,
    marginBottom: 8,
    fontSize: 12,
    textAlign: "center",
  },
  podiumBlock: {
    width: "100%",
    borderTopLeftRadius: theme.radius.lg,
    borderTopRightRadius: theme.radius.lg,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.10)",
    alignItems: "center",
    justifyContent: "center",
  },
  podiumBlockFeatured: {
    backgroundColor: "rgba(214,179,106,0.18)",
  },
  podiumPlace: {
    color: theme.colors.gold2,
    fontSize: 34,
    fontWeight: "900",
  },
  sectionTitle: {
    color: theme.colors.gold2,
    fontSize: 22,
    fontWeight: "900",
    marginBottom: 12,
  },
  stack: {
    gap: 10,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
  },
  leftGroup: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    flex: 1,
  },
  rankPill: {
    minWidth: 48,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: theme.radius.pill,
    backgroundColor: "rgba(214,179,106,0.14)",
    alignItems: "center",
  },
  rankText: {
    color: theme.colors.gold2,
    fontWeight: "900",
    fontSize: 12,
  },
  avatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
  },
  avatarFallback: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: "rgba(214,179,106,0.12)",
    alignItems: "center",
    justifyContent: "center",
  },
  avatarFallbackText: {
    color: theme.colors.gold2,
    fontWeight: "900",
  },
  rowName: {
    color: theme.colors.text,
    fontSize: 16,
    fontWeight: "800",
    flexShrink: 1,
  },
  rowBalance: {
    color: theme.colors.gold2,
    fontSize: 16,
    fontWeight: "900",
  },
  empty: {
    color: theme.colors.textSoft,
    textAlign: "center",
  },
});
