import { useCallback, useMemo, useState } from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { useFocusEffect } from "expo-router";
import ScreenContainer from "../../src/components/ScreenContainer";
import ThemedCard from "../../src/components/ThemedCard";
import ThemedButton from "../../src/components/ThemedButton";
import AppModal from "../../src/components/AppModal";
import { api } from "../../src/lib/api";
import { BonusRow, fetchBonuses, getErrorMessage } from "../../src/lib/bonusApi";
import { formatAmount, theme } from "../../src/theme/theme";

const coinImage = require("../../assets/images/doubleo-coin.png");

export default function BonusesScreen() {
  const [bonuses, setBonuses] = useState<BonusRow[]>([]);
  const [balance, setBalance] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingId, setLoadingId] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ visible: boolean; title: string; message?: string }>({
    visible: false,
    title: "",
    message: "",
  });
  const [loadError, setLoadError] = useState("");

  async function loadData() {
    try {
      const [balanceRes, bonusesData] = await Promise.all([
        api.get("/balances/me"),
        fetchBonuses(false),
      ]);

      setBalance(Number(balanceRes.data?.balance || 0));
      setBonuses(bonusesData.filter((item) => item.isActive));
      setLoadError("");
    } catch (error: any) {
      setLoadError(getErrorMessage(error, "Unable to load bonuses right now."));
      setBonuses([]);
    }
  }

  async function onRefresh() {
    try {
      setRefreshing(true);
      await loadData();
    } finally {
      setRefreshing(false);
    }
  }

  useFocusEffect(
    useCallback(() => {
      loadData().catch(() => {});
    }, []),
  );

  const eligible = balance < 300;
  const availableCount = useMemo(() => bonuses.filter((item) => !item.hasPendingRequest).length, [bonuses]);

  async function requestBonus(item: BonusRow) {
    if (!eligible) {
      setFeedback({
        visible: true,
        title: "Not eligible",
        message: "Only members under 300 O² can request a bonus.",
      });
      return;
    }

    if (item.hasPendingRequest) {
      setFeedback({
        visible: true,
        title: "Already requested",
        message: "A request for this bonus was already sent.",
      });
      return;
    }

    try {
      setLoadingId(item.id);
      await api.post(`/bonuses/${item.id}/request`);
      await loadData();
      setFeedback({
        visible: true,
        title: "Request sent",
        message: "The admin can now approve or reject this bonus request.",
      });
    } catch (error: any) {
      const status = error?.response?.status;
      setFeedback({
        visible: true,
        title: status === 409 ? "Already requested" : "Unable to send request",
        message:
          status === 409
            ? "A request for this bonus was already sent."
            : getErrorMessage(error, "Failed to send bonus request."),
      });
    } finally {
      setLoadingId(null);
    }
  }

  return (
    <>
      <ScreenContainer refreshing={refreshing} onRefresh={onRefresh}>
        <View style={styles.header}>
          <Text style={styles.title}>Bonuses</Text>
          <Image source={coinImage} style={styles.coin} />
        </View>

        <View style={styles.metricsRow}>
          <MiniMetric label="Balance" value={`${formatAmount(balance)} O²`} />
          <MiniMetric label="Eligible" value={eligible ? "Yes" : "No"} />
          <MiniMetric label="Open" value={String(availableCount)} />
        </View>

        {!eligible ? (
          <ThemedCard glow="none" style={styles.noticeCard}>
            <Text style={styles.noticeTitle}>Bonus entry is locked</Text>
            <Text style={styles.noticeText}>Only members under 300 O² can send a bonus request.</Text>
          </ThemedCard>
        ) : null}

        {loadError ? (
          <ThemedCard glow="none" style={styles.noticeCard}>
            <Text style={styles.noticeTitle}>Could not load bonuses</Text>
            <Text style={styles.noticeText}>{loadError}</Text>
          </ThemedCard>
        ) : null}

        <View style={styles.stack}>
          {bonuses.map((item) => {
            const disabled = !eligible || item.hasPendingRequest || loadingId === item.id;
            return (
              <ThemedCard key={item.id} glow="none">
                {item.imageUri ? <Image source={{ uri: item.imageUri }} style={styles.bonusImage} /> : null}

                <View style={styles.cardTop}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.bonusTitle}>{item.title}</Text>
                    <Text style={styles.bonusAmount}>{formatAmount(item.amount)} O²</Text>
                  </View>
                </View>

                {item.description ? <Text style={styles.description}>{item.description}</Text> : null}

                <ThemedButton
                  title={
                    loadingId === item.id
                      ? "Sending..."
                      : item.hasPendingRequest
                        ? "Pending"
                        : eligible
                          ? "Request Bonus"
                          : "Need under 300 O²"
                  }
                  onPress={() => requestBonus(item)}
                  disabled={disabled}
                  loading={loadingId === item.id}
                  variant={eligible && !item.hasPendingRequest ? "gold" : "dark"}
                />
              </ThemedCard>
            );
          })}

          {!loadError && bonuses.length === 0 ? (
            <ThemedCard glow="none">
              <Text style={styles.empty}>No bonuses are available right now.</Text>
            </ThemedCard>
          ) : null}
        </View>
      </ScreenContainer>

      <AppModal
        visible={feedback.visible}
        title={feedback.title}
        message={feedback.message}
        onConfirm={() => setFeedback({ visible: false, title: "", message: "" })}
        confirmLabel="Close"
      />
    </>
  );
}

function MiniMetric({ label, value }: { label: string; value: string }) {
  return (
    <ThemedCard glow="none" style={styles.metricCard}>
      <Text style={styles.metricLabel}>{label}</Text>
      <Text style={styles.metricValue}>{value}</Text>
    </ThemedCard>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    gap: 12,
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 14,
  },
  title: {
    color: theme.colors.gold2,
    fontSize: 32,
    fontWeight: "900",
  },
  coin: {
    width: 68,
    height: 68,
  },
  metricsRow: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 14,
  },
  metricCard: {
    flex: 1,
  },
  metricLabel: {
    color: theme.colors.textSoft,
    fontSize: 11,
    fontWeight: "700",
    textTransform: "uppercase",
    letterSpacing: 1,
  },
  metricValue: {
    color: theme.colors.gold2,
    fontSize: 18,
    fontWeight: "900",
    marginTop: 6,
  },
  noticeCard: {
    marginBottom: 14,
  },
  noticeTitle: {
    color: theme.colors.gold2,
    fontSize: 18,
    fontWeight: "900",
  },
  noticeText: {
    color: theme.colors.textSoft,
    marginTop: 8,
    lineHeight: 21,
  },
  stack: {
    gap: 12,
  },
  bonusImage: {
    width: "100%",
    height: 180,
    borderRadius: theme.radius.md,
    marginBottom: 14,
  },
  cardTop: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 12,
  },
  bonusTitle: {
    color: theme.colors.text,
    fontSize: 22,
    fontWeight: "900",
  },
  bonusAmount: {
    color: theme.colors.gold2,
    fontSize: 20,
    fontWeight: "900",
    marginTop: 4,
  },
  description: {
    color: theme.colors.textSoft,
    lineHeight: 22,
    marginTop: 10,
    marginBottom: 16,
  },
  empty: {
    color: theme.colors.textSoft,
    textAlign: "center",
  },
});
