import { useCallback, useMemo, useState } from "react";
import { Image, Pressable, StyleSheet, Text, View } from "react-native";
import { useFocusEffect } from "expo-router";
import ScreenContainer from "../../src/components/ScreenContainer";
import ThemedCard from "../../src/components/ThemedCard";
import ThemedButton from "../../src/components/ThemedButton";
import { api } from "../../src/lib/api";
import { useAuth } from "../../src/context/AuthContext";
import { formatAmount, formatDateTime, theme } from "../../src/theme/theme";

const coinImage = require("../../assets/images/doubleo-coin.png");

type ScopeFilter = "mine" | "all";
type StatusFilter = "all" | "approved" | "rejected" | "pending";

type ActionRow = {
  id: string;
  action_type: "BUY_IN" | "CASH_OUT" | "BONUS";
  username: string;
  amount: number;
  status: "PENDING" | "APPROVED" | "REJECTED";
  note: string | null;
  created_at: string;
  admin_username?: string | null;
  source_kind: "REQUEST" | "BONUS";
};

export default function ActionsScreen() {
  const { user } = useAuth();
  const isAdmin = user?.role === "ADMIN";

  const [refreshing, setRefreshing] = useState(false);
  const [scope, setScope] = useState<ScopeFilter>("mine");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [actions, setActions] = useState<ActionRow[]>([]);

  async function loadData(nextScope = scope, nextStatus = statusFilter) {
    const response = await api.get(`/conversion-requests?scope=${nextScope}&status=${nextStatus}`);
    setActions(response.data);
  }

  async function onRefresh() {
    try {
      setRefreshing(true);
      await loadData();
    } finally {
      setRefreshing(false);
    }
  }

  useFocusEffect(
    useCallback(() => {
      loadData().catch(() => {});
    }, [scope, statusFilter]),
  );

  const pendingCount = useMemo(() => {
    return actions.filter((item) => item.status === "PENDING").length;
  }, [actions]);

  return (
    <ScreenContainer refreshing={refreshing} onRefresh={onRefresh}>
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>Actions</Text>
          <Text style={styles.subtitle}>
            Filter all conversions and bonuses together, instead of splitting history into two separate places.
          </Text>
        </View>
        <Image source={coinImage} style={styles.coin} />
      </View>

      <ThemedCard glow="gold" style={styles.heroCard}>
        <View style={styles.heroRow}>
          <View style={styles.heroBox}>
            <Text style={styles.heroLabel}>Visible Now</Text>
            <Text style={styles.heroValue}>{actions.length}</Text>
          </View>
          <View style={styles.heroBox}>
            <Text style={styles.heroLabel}>Pending</Text>
            <Text style={styles.heroValue}>{pendingCount}</Text>
          </View>
        </View>

        {isAdmin ? (
          <View style={{ marginTop: 16 }}>
            <ThemedButton title="Manual conversions are available from Profile" variant="ghost" onPress={() => {}} />
          </View>
        ) : (
          <Text style={styles.tipText}>Live buy-in and cash-out requests are handled from the Session screen.</Text>
        )}
      </ThemedCard>

      <Text style={styles.sectionTitle}>Filters</Text>
      <View style={styles.filterRow}>
        <Segment active={scope === "mine"} label="Mine" onPress={() => setScope("mine")} />
        <Segment active={scope === "all"} label="All" onPress={() => setScope("all")} />
      </View>
      <View style={styles.filterRow}>
        <Segment active={statusFilter === "all"} label="All" onPress={() => setStatusFilter("all")} />
        <Segment
          active={statusFilter === "pending"}
          label="Pending"
          onPress={() => setStatusFilter("pending")}
        />
      </View>
      <View style={styles.filterRow}>
        <Segment
          active={statusFilter === "approved"}
          label="Approved"
          onPress={() => setStatusFilter("approved")}
        />
        <Segment
          active={statusFilter === "rejected"}
          label="Rejected"
          onPress={() => setStatusFilter("rejected")}
        />
      </View>

      <Text style={styles.sectionTitle}>Activity Feed</Text>
      <View style={styles.stack}>
        {actions.map((item) => (
          <ThemedCard key={item.id} glow="none">
            <View style={styles.rowTop}>
              <View style={{ flex: 1 }}>
                <View style={styles.titleRow}>
                  <Text style={styles.actionTitle}>{getActionLabel(item.action_type)}</Text>
                  {scope === "all" ? <Text style={styles.dot}>•</Text> : null}
                  {scope === "all" ? <Text style={styles.username}>{item.username}</Text> : null}
                </View>
                <Text style={styles.actionSub}>{item.note || getDefaultNote(item.action_type)}</Text>
              </View>
              {item.action_type === "BONUS" ? (
                <View style={styles.bonusBadge}>
                  <Text style={styles.bonusBadgeText}>BONUS</Text>
                </View>
              ) : (
                <StatusBadge status={item.status} />
              )}
            </View>

            <View style={styles.metaRow}>
              <Text style={styles.amount}>{formatAmount(item.amount)} O²</Text>
              <Text style={styles.date}>{formatDateTime(item.created_at)}</Text>
            </View>
          </ThemedCard>
        ))}

        {actions.length === 0 ? (
          <ThemedCard glow="none">
            <Text style={styles.empty}>No actions match the current filters.</Text>
          </ThemedCard>
        ) : null}
      </View>
    </ScreenContainer>
  );
}

function Segment({
  active,
  label,
  onPress,
}: {
  active: boolean;
  label: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={[styles.segment, active ? styles.segmentActive : styles.segmentInactive]}
    >
      <Text style={[styles.segmentText, active && styles.segmentTextActive]}>{label}</Text>
    </Pressable>
  );
}

function StatusBadge({ status }: { status: "PENDING" | "APPROVED" | "REJECTED" }) {
  const bg =
    status === "APPROVED"
      ? "rgba(88,211,155,0.15)"
      : status === "REJECTED"
        ? "rgba(255,107,129,0.15)"
        : "rgba(214,179,106,0.14)";

  const color =
    status === "APPROVED"
      ? theme.colors.success
      : status === "REJECTED"
        ? theme.colors.danger
        : theme.colors.gold2;

  return (
    <View style={[styles.badge, { backgroundColor: bg }]}>
      <Text style={[styles.badgeText, { color }]}>{status}</Text>
    </View>
  );
}

function getActionLabel(actionType: ActionRow["action_type"]) {
  if (actionType === "BUY_IN") return "Buy In";
  if (actionType === "CASH_OUT") return "Cash Out";
  return "Bonus";
}

function getDefaultNote(actionType: ActionRow["action_type"]) {
  if (actionType === "BUY_IN") return "Conversion request into chips";
  if (actionType === "CASH_OUT") return "Conversion request back into Double O";
  return "Bonus granted to the member";
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    gap: 12,
    alignItems: "center",
    marginBottom: 16,
  },
  title: {
    color: theme.colors.gold2,
    fontSize: 32,
    fontWeight: "900",
  },
  subtitle: {
    color: theme.colors.textSoft,
    marginTop: 6,
    lineHeight: 21,
  },
  coin: {
    width: 72,
    height: 72,
  },
  heroCard: {
    marginBottom: 18,
  },
  heroRow: {
    flexDirection: "row",
    gap: 10,
  },
  heroBox: {
    flex: 1,
    borderRadius: theme.radius.md,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.07)",
    padding: 12,
    alignItems: "center",
  },
  heroLabel: {
    color: theme.colors.gold2,
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 1,
    textTransform: "uppercase",
  },
  heroValue: {
    color: theme.colors.text,
    fontSize: 24,
    fontWeight: "900",
    marginTop: 6,
  },
  tipText: {
    color: theme.colors.textSoft,
    lineHeight: 21,
    marginTop: 14,
  },
  sectionTitle: {
    color: theme.colors.gold2,
    fontSize: 22,
    fontWeight: "900",
    marginBottom: 12,
  },
  filterRow: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 10,
  },
  segment: {
    flex: 1,
    minHeight: 42,
    borderRadius: theme.radius.pill,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1.2,
  },
  segmentActive: {
    backgroundColor: "rgba(214,179,106,0.18)",
    borderColor: theme.colors.borderStrong,
  },
  segmentInactive: {
    backgroundColor: "rgba(255,255,255,0.02)",
    borderColor: theme.colors.border,
  },
  segmentText: {
    color: theme.colors.textSoft,
    fontWeight: "800",
    fontSize: 12,
  },
  segmentTextActive: {
    color: theme.colors.gold2,
  },
  stack: {
    gap: 12,
  },
  rowTop: {
    flexDirection: "row",
    gap: 12,
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
  titleRow: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
    gap: 6,
  },
  actionTitle: {
    color: theme.colors.text,
    fontSize: 18,
    fontWeight: "900",
  },
  dot: {
    color: theme.colors.textSoft,
  },
  username: {
    color: theme.colors.textSoft,
    fontWeight: "700",
  },
  actionSub: {
    color: theme.colors.textSoft,
    marginTop: 6,
    lineHeight: 20,
  },
  metaRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 10,
    marginTop: 14,
  },
  amount: {
    color: theme.colors.gold2,
    fontSize: 20,
    fontWeight: "900",
  },
  date: {
    color: theme.colors.muted,
    fontSize: 12,
  },
  badge: {
    borderRadius: theme.radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  badgeText: {
    fontSize: 11,
    fontWeight: "900",
    letterSpacing: 0.7,
  },
  bonusBadge: {
    borderRadius: theme.radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 6,
    backgroundColor: "rgba(88,211,155,0.15)",
  },
  bonusBadgeText: {
    color: theme.colors.success,
    fontSize: 11,
    fontWeight: "900",
    letterSpacing: 0.7,
  },
  empty: {
    color: theme.colors.textSoft,
    textAlign: "center",
  },
});
