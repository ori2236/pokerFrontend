import { useCallback, useMemo, useState } from "react";
import { Alert, Image, StyleSheet, Text, View } from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import ScreenContainer from "../../src/components/ScreenContainer";
import ThemedCard from "../../src/components/ThemedCard";
import ThemedButton from "../../src/components/ThemedButton";
import { api } from "../../src/lib/api";
import { useAuth } from "../../src/context/AuthContext";
import { formatAmount, formatShortDate, theme } from "../../src/theme/theme";

const coinImage = require("../../assets/images/doubleo-coin.png");

type UserRow = {
  id: number;
  username: string;
  role: "ADMIN" | "USER";
  profile_image_base64: string | null;
};

type LeaderboardUser = {
  rank: number;
  id: number;
  username: string;
  balance: number;
};

type DailySummary = {
  date: string;
  totalIn: number;
  totalOut: number;
  net: number;
};

export default function ProfileScreen() {
  const router = useRouter();
  const { user, logout } = useAuth();

  const [profile, setProfile] = useState<UserRow | null>(null);
  const [balance, setBalance] = useState(0);
  const [todayNet, setTodayNet] = useState(0);
  const [dailySummary, setDailySummary] = useState<DailySummary[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  async function loadData() {
    const [usersRes, balanceRes, leaderboardRes, summaryRes] = await Promise.all([
      api.get("/users"),
      api.get("/balances/me"),
      api.get("/balances/leaderboard"),
      api.get("/transactions/daily-summary/me"),
    ]);

    const me = usersRes.data.find((item: UserRow) => item.id === user?.id) || null;

    setProfile(me);
    setBalance(balanceRes.data.balance);
    setTodayNet(balanceRes.data.todayNet);
    setLeaderboard(leaderboardRes.data);
    setDailySummary(summaryRes.data.slice(0, 5));
  }

  async function onRefresh() {
    try {
      setRefreshing(true);
      await loadData();
    } finally {
      setRefreshing(false);
    }
  }

  useFocusEffect(
    useCallback(() => {
      loadData().catch(() => {});
    }, []),
  );

  async function onLogout() {
    try {
      await logout();
      router.replace("/login");
    } catch {
      Alert.alert("Error", "Failed to log out");
    }
  }

  const myRank = useMemo(() => {
    return leaderboard.find((entry) => entry.id === user?.id)?.rank ?? null;
  }, [leaderboard, user?.id]);

  const profileUri = profile?.profile_image_base64
    ? `data:image/jpeg;base64,${profile.profile_image_base64}`
    : null;

  const isAdmin = user?.role === "ADMIN";

  return (
    <ScreenContainer refreshing={refreshing} onRefresh={onRefresh}>
      <ThemedCard glow="gold" style={styles.heroCard}>
        <View style={styles.heroTop}>
          <View style={styles.avatarShell}>
            {profileUri ? (
              <Image source={{ uri: profileUri }} style={styles.avatar} />
            ) : (
              <View style={styles.avatarFallback}>
                <Text style={styles.avatarFallbackText}>O²</Text>
              </View>
            )}
          </View>

          <View style={{ flex: 1 }}>
            <Text style={styles.eyebrow}>{isAdmin ? "Table Manager" : "Club Member"}</Text>
            <Text style={styles.name}>{profile?.username || user?.username}</Text>
            <Text style={styles.roleLine}>
              {isAdmin ? "Admin access enabled" : "Ready for the next game"}
            </Text>
          </View>

          <Image source={coinImage} style={styles.coin} />
        </View>

        <View style={styles.statsRow}>
          <StatBox label="Balance" value={formatAmount(balance)} />
          <StatBox label="Rank" value={myRank ? `#${myRank}` : "-"} />
          <StatBox
            label="Today"
            value={`${todayNet >= 0 ? "+" : ""}${formatAmount(todayNet)}`}
            valueColor={todayNet >= 0 ? theme.colors.success : theme.colors.danger}
          />
        </View>
      </ThemedCard>

      <ThemedCard glow="none" style={styles.actionsCard}>
        <Text style={styles.cardTitle}>Profile Actions</Text>
        <Text style={styles.cardSubtitle}>
          Keep the profile clean here, and move any edits into a dedicated screen.
        </Text>

        <View style={styles.buttonStack}>
          <ThemedButton title="Edit Profile" onPress={() => router.push("/edit-profile")} />
          {isAdmin ? (
            <ThemedButton
              title="Open Manual Conversions"
              variant="dark"
              onPress={() => router.push("/admin-conversion")}
            />
          ) : null}
          <ThemedButton title="Log Out" variant="ghost" onPress={onLogout} />
        </View>
      </ThemedCard>

      <ThemedCard glow="none">
        <Text style={styles.cardTitle}>Recent Daily Results</Text>
        <View style={styles.summaryStack}>
          {dailySummary.length === 0 ? (
            <Text style={styles.emptyText}>No activity yet.</Text>
          ) : (
            dailySummary.map((item) => (
              <View key={item.date} style={styles.summaryRow}>
                <View>
                  <Text style={styles.summaryDate}>{formatShortDate(item.date)}</Text>
                  <Text style={styles.summarySub}>
                    In {formatAmount(item.totalIn)} · Out {formatAmount(item.totalOut)}
                  </Text>
                </View>
                <Text
                  style={[
                    styles.summaryNet,
                    { color: item.net >= 0 ? theme.colors.success : theme.colors.danger },
                  ]}
                >
                  {item.net >= 0 ? "+" : ""}
                  {formatAmount(item.net)}
                </Text>
              </View>
            ))
          )}
        </View>
      </ThemedCard>
    </ScreenContainer>
  );
}

function StatBox({
  label,
  value,
  valueColor,
}: {
  label: string;
  value: string;
  valueColor?: string;
}) {
  return (
    <View style={styles.statBox}>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={[styles.statValue, valueColor ? { color: valueColor } : null]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  heroCard: {
    marginBottom: 18,
  },
  heroTop: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
  },
  avatarShell: {
    width: 86,
    height: 86,
    borderRadius: 43,
    padding: 3,
    borderWidth: 1.4,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.12)",
  },
  avatar: {
    width: "100%",
    height: "100%",
    borderRadius: 40,
  },
  avatarFallback: {
    flex: 1,
    borderRadius: 40,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(214,179,106,0.12)",
  },
  avatarFallbackText: {
    color: theme.colors.gold2,
    fontSize: 28,
    fontWeight: "900",
  },
  eyebrow: {
    color: theme.colors.gold2,
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 1.4,
    textTransform: "uppercase",
  },
  name: {
    color: theme.colors.text,
    fontSize: 28,
    fontWeight: "900",
    marginTop: 6,
  },
  roleLine: {
    color: theme.colors.textSoft,
    marginTop: 4,
  },
  coin: {
    width: 56,
    height: 56,
  },
  statsRow: {
    flexDirection: "row",
    gap: 10,
    marginTop: 18,
  },
  statBox: {
    flex: 1,
    borderRadius: theme.radius.md,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.07)",
    padding: 12,
    alignItems: "center",
  },
  statLabel: {
    color: theme.colors.gold2,
    fontSize: 11,
    fontWeight: "800",
    textTransform: "uppercase",
    letterSpacing: 1,
  },
  statValue: {
    color: theme.colors.text,
    fontSize: 20,
    fontWeight: "900",
    marginTop: 6,
  },
  actionsCard: {
    marginBottom: 18,
  },
  cardTitle: {
    color: theme.colors.gold2,
    fontSize: 20,
    fontWeight: "900",
  },
  cardSubtitle: {
    color: theme.colors.textSoft,
    marginTop: 8,
    lineHeight: 21,
  },
  buttonStack: {
    gap: 12,
    marginTop: 16,
  },
  summaryStack: {
    gap: 12,
    marginTop: 14,
  },
  summaryRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  summaryDate: {
    color: theme.colors.text,
    fontSize: 16,
    fontWeight: "800",
  },
  summarySub: {
    color: theme.colors.textSoft,
    marginTop: 4,
  },
  summaryNet: {
    fontSize: 18,
    fontWeight: "900",
  },
  emptyText: {
    color: theme.colors.textSoft,
    textAlign: "center",
  },
});
