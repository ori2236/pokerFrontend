import { useCallback, useMemo, useState } from "react";
import { Alert, Image, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import ScreenContainer from "../src/components/ScreenContainer";
import ThemedCard from "../src/components/ThemedCard";
import ThemedButton from "../src/components/ThemedButton";
import LuxuryInput from "../src/components/LuxuryInput";
import { api } from "../src/lib/api";
import { formatAmount, theme } from "../src/theme/theme";

const whiteChip = require("../assets/chips/white.png");
const redChip = require("../assets/chips/red.png");
const blueChip = require("../assets/chips/blue.png");
const greenChip = require("../assets/chips/green.png");
const blackChip = require("../assets/chips/black.png");
const coinImage = require("../assets/images/doubleo-coin.png");

type ChipKey = "white" | "red" | "blue" | "green" | "black";
type ChipCounts = Record<ChipKey, number>;
type InputMode = "TOTAL_AMOUNT" | "CHIP_BREAKDOWN";
type ConversionType = "TO_CHIPS" | "TO_COINS";

type UserRow = {
  id: number;
  username: string;
  role: "ADMIN" | "USER";
};

type ActiveSessionResponse = {
  activeSession: null | {
    id: number;
    title: string;
  };
};

const chipConfig: Array<{ key: ChipKey; label: string; value: number; image: any }> = [
  { key: "white", label: "White", value: 1, image: whiteChip },
  { key: "red", label: "Red", value: 5, image: redChip },
  { key: "blue", label: "Blue", value: 10, image: blueChip },
  { key: "green", label: "Green", value: 25, image: greenChip },
  { key: "black", label: "Black", value: 50, image: blackChip },
];

export default function AdminConversionScreen() {
  const router = useRouter();

  const [users, setUsers] = useState<UserRow[]>([]);
  const [session, setSession] = useState<ActiveSessionResponse["activeSession"]>(null);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [userPickerOpen, setUserPickerOpen] = useState(false);
  const [type, setType] = useState<ConversionType>("TO_CHIPS");
  const [mode, setMode] = useState<InputMode>("TOTAL_AMOUNT");
  const [amount, setAmount] = useState("");
  const [chips, setChips] = useState<ChipCounts>({
    white: 0,
    red: 0,
    blue: 0,
    green: 0,
    black: 0,
  });
  const [submitting, setSubmitting] = useState(false);

  async function loadData() {
    const [usersRes, sessionRes] = await Promise.all([
      api.get("/users"),
      api.get("/sessions/active"),
    ]);

    setUsers(usersRes.data);
    setSession(sessionRes.data.activeSession);

    if (!selectedUserId && usersRes.data.length > 0) {
      setSelectedUserId(usersRes.data[0].id);
    }
  }

  useFocusEffect(
    useCallback(() => {
      loadData().catch(() => {});
    }, []),
  );

  const selectedUser = useMemo(() => {
    return users.find((entry) => entry.id === selectedUserId) || null;
  }, [users, selectedUserId]);

  const totalFromChips = useMemo(() => {
    return (
      chips.white * 1 +
      chips.red * 5 +
      chips.blue * 10 +
      chips.green * 25 +
      chips.black * 50
    );
  }, [chips]);

  function updateChip(key: ChipKey, value: string) {
    const numeric = Math.max(0, Number(value.replace(/[^0-9]/g, "") || 0));
    setChips((prev) => ({ ...prev, [key]: numeric }));
  }

  function resetForm() {
    setAmount("");
    setChips({ white: 0, red: 0, blue: 0, green: 0, black: 0 });
  }

  async function submit() {
    try {
      if (!selectedUserId) {
        Alert.alert("Missing user", "Choose who the conversion is for.");
        return;
      }

      setSubmitting(true);

      if (mode === "TOTAL_AMOUNT") {
        if (amount === "" || Number(amount) < 0) {
          Alert.alert("Invalid amount", "Enter a valid amount.");
          return;
        }

        if (type === "TO_CHIPS" && Number(amount) <= 0) {
          Alert.alert("Invalid amount", "Buy-in must be greater than 0.");
          return;
        }

        await api.post("/conversion-requests", {
          target_user_id: selectedUserId,
          type,
          amount_mode: "TOTAL_AMOUNT",
          amount_total: Number(amount),
        });
      } else {
        if (type === "TO_CHIPS" && totalFromChips <= 0) {
          Alert.alert("Invalid chips", "Enter at least one chip.");
          return;
        }

        await api.post("/conversion-requests", {
          target_user_id: selectedUserId,
          type,
          amount_mode: "CHIP_BREAKDOWN",
          white_count: chips.white,
          red_count: chips.red,
          blue_count: chips.blue,
          green_count: chips.green,
          black_count: chips.black,
        });
      }

      resetForm();
      Alert.alert("Done", "Manual conversion completed successfully.");
      await loadData();
    } catch (error: any) {
      Alert.alert("Error", error?.response?.data?.message || "Failed to complete conversion");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <ScreenContainer>
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>Manual Conversions</Text>
          <Text style={styles.subtitle}>
            As admin you can convert for anyone, even when no session is active.
          </Text>
        </View>
        <Image source={coinImage} style={styles.coin} />
      </View>

      <ThemedCard glow="gold" style={styles.cardSpacing}>
        <Text style={styles.cardTitle}>Current Table Status</Text>
        <Text style={styles.sessionText}>
          {session ? `Active session: ${session.title}` : "No active session right now."}
        </Text>
      </ThemedCard>

      <ThemedCard glow="none">
        <Text style={styles.cardTitle}>Select Member</Text>

        <Pressable style={styles.dropdown} onPress={() => setUserPickerOpen((prev) => !prev)}>
          <Text style={styles.dropdownText}>
            {selectedUser ? selectedUser.username : "Choose a member"}
          </Text>
          <Text style={styles.dropdownArrow}>{userPickerOpen ? "▲" : "▼"}</Text>
        </Pressable>

        {userPickerOpen ? (
          <View style={styles.dropdownList}>
            {users.map((item) => {
              const active = item.id === selectedUserId;
              return (
                <Pressable
                  key={item.id}
                  onPress={() => {
                    setSelectedUserId(item.id);
                    setUserPickerOpen(false);
                  }}
                  style={[styles.dropdownItem, active && styles.dropdownItemActive]}
                >
                  <Text style={[styles.dropdownItemText, active && styles.dropdownItemTextActive]}>
                    {item.username}
                  </Text>
                  <Text style={styles.dropdownRole}>{item.role}</Text>
                </Pressable>
              );
            })}
          </View>
        ) : null}

        <View style={styles.segmentRow}>
          <Segment active={type === "TO_CHIPS"} label="Buy In" onPress={() => setType("TO_CHIPS")} />
          <Segment active={type === "TO_COINS"} label="Cash Out" onPress={() => setType("TO_COINS")} />
        </View>

        <View style={styles.segmentRow}>
          <Segment active={mode === "TOTAL_AMOUNT"} label="Amount" onPress={() => setMode("TOTAL_AMOUNT")} />
          <Segment active={mode === "CHIP_BREAKDOWN"} label="Chips" onPress={() => setMode("CHIP_BREAKDOWN")} />
        </View>

        {mode === "TOTAL_AMOUNT" ? (
          <View style={{ marginTop: 16 }}>
            <LuxuryInput
              label={type === "TO_CHIPS" ? "Double O amount" : "Cash out amount"}
              placeholder="Enter amount"
              keyboardType="numeric"
              value={amount}
              onChangeText={setAmount}
            />
          </View>
        ) : (
          <View style={{ marginTop: 16, gap: 12 }}>
            {chipConfig.map((chip) => (
              <View key={chip.key} style={styles.chipRow}>
                <View style={styles.chipLeft}>
                  <Image source={chip.image} style={styles.chipImage} />
                  <View>
                    <Text style={styles.chipName}>{chip.label}</Text>
                    <Text style={styles.chipValue}>Value: {chip.value}</Text>
                  </View>
                </View>

                <TextInput
                  value={chips[chip.key] ? String(chips[chip.key]) : ""}
                  onChangeText={(value) => updateChip(chip.key, value)}
                  keyboardType="numeric"
                  placeholder="0"
                  placeholderTextColor={theme.colors.muted}
                  style={styles.chipInput}
                />
              </View>
            ))}

            <View style={styles.totalBox}>
              <Text style={styles.totalLabel}>Calculated total</Text>
              <Text style={styles.totalValue}>{formatAmount(totalFromChips)} O²</Text>
            </View>
          </View>
        )}

        <View style={styles.buttonStack}>
          <ThemedButton
            title={submitting ? "Working..." : "Submit Conversion"}
            onPress={submit}
            loading={submitting}
          />
          <ThemedButton title="Back to Profile" variant="ghost" onPress={() => router.back()} />
        </View>
      </ThemedCard>
    </ScreenContainer>
  );
}

function Segment({
  active,
  label,
  onPress,
}: {
  active: boolean;
  label: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={[styles.segment, active ? styles.segmentActive : styles.segmentInactive]}
    >
      <Text style={[styles.segmentText, active && styles.segmentTextActive]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    gap: 12,
    alignItems: "center",
    marginBottom: 16,
  },
  title: {
    color: theme.colors.gold2,
    fontSize: 32,
    fontWeight: "900",
  },
  subtitle: {
    color: theme.colors.textSoft,
    marginTop: 6,
    lineHeight: 21,
  },
  coin: {
    width: 72,
    height: 72,
  },
  cardSpacing: {
    marginBottom: 18,
  },
  cardTitle: {
    color: theme.colors.gold2,
    fontSize: 20,
    fontWeight: "900",
  },
  sessionText: {
    color: theme.colors.textSoft,
    marginTop: 8,
  },
  dropdown: {
    minHeight: 52,
    borderRadius: theme.radius.md,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.07)",
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 14,
  },
  dropdownText: {
    color: theme.colors.text,
    fontSize: 16,
    fontWeight: "800",
  },
  dropdownArrow: {
    color: theme.colors.gold2,
    fontWeight: "900",
  },
  dropdownList: {
    gap: 8,
    marginTop: 12,
  },
  dropdownItem: {
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    backgroundColor: "rgba(255,255,255,0.03)",
    padding: 12,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  dropdownItemActive: {
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.10)",
  },
  dropdownItemText: {
    color: theme.colors.text,
    fontWeight: "800",
  },
  dropdownItemTextActive: {
    color: theme.colors.gold2,
  },
  dropdownRole: {
    color: theme.colors.textSoft,
    fontSize: 12,
    fontWeight: "700",
  },
  segmentRow: {
    flexDirection: "row",
    gap: 10,
    marginTop: 14,
  },
  segment: {
    flex: 1,
    minHeight: 42,
    borderRadius: theme.radius.pill,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1.2,
  },
  segmentActive: {
    backgroundColor: "rgba(214,179,106,0.18)",
    borderColor: theme.colors.borderStrong,
  },
  segmentInactive: {
    backgroundColor: "rgba(255,255,255,0.02)",
    borderColor: theme.colors.border,
  },
  segmentText: {
    color: theme.colors.textSoft,
    fontWeight: "800",
    fontSize: 12,
  },
  segmentTextActive: {
    color: theme.colors.gold2,
  },
  chipRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
  },
  chipLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    flex: 1,
  },
  chipImage: {
    width: 52,
    height: 52,
    resizeMode: "contain",
  },
  chipName: {
    color: theme.colors.text,
    fontSize: 16,
    fontWeight: "800",
  },
  chipValue: {
    color: theme.colors.textSoft,
    marginTop: 2,
  },
  chipInput: {
    width: 78,
    minHeight: 46,
    borderRadius: theme.radius.pill,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.06)",
    color: theme.colors.text,
    textAlign: "center",
    fontSize: 16,
    fontWeight: "800",
  },
  totalBox: {
    borderRadius: theme.radius.md,
    borderWidth: 1.2,
    borderColor: theme.colors.borderStrong,
    backgroundColor: "rgba(214,179,106,0.08)",
    padding: 14,
    alignItems: "center",
  },
  totalLabel: {
    color: theme.colors.textSoft,
    fontSize: 12,
    fontWeight: "700",
    textTransform: "uppercase",
    letterSpacing: 1,
  },
  totalValue: {
    color: theme.colors.gold2,
    fontSize: 24,
    fontWeight: "900",
    marginTop: 6,
  },
  buttonStack: {
    marginTop: 18,
    gap: 12,
  },
});
